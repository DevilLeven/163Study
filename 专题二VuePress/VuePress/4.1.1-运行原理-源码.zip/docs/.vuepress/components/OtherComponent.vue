<template>
  <p class="demo">This is another component</p>
</template>
